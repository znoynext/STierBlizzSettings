local _, STBS = ...

local strings = {
  enUS = {
    APPLY_AND_MEASURE="Apply and measure FPS", APPLY_CONFIRM="Apply graphics settings?", APPLY_CONFIRM_TEXT="Apply %d reviewed changes? A graphics backup will be created first.", SETTINGS_APPLIED="Graphics applied. Measuring FPS now…",
    FPS_RESULT_FORMAT="Average FPS: %d to %d, %+d FPS (%+d%%)", FPS_MEASURING="Measuring FPS… keep the same view.", FPS_MEASURE_HELP="FPS is measured locally before and after applying. The result is an estimate and depends on the scene, combat and background load.", FPS_UNAVAILABLE="FPS comparison is not available yet.", FPS_ESTIMATE="Local FPS estimate",
    VISUAL_PREVIEW="Balanced graphics preview", VISUAL_PREVIEW_NOTE="Illustrative preview: clear silhouettes, projected effects and restrained particles are preserved.", UNDO="Undo graphics changes", UNDO_CONFIRM="Restore previous graphics?", UNDO_CONFIRM_TEXT="Restore the latest graphics backup? A safety backup will be created first.", UNDO_UNAVAILABLE="No graphics backup is available yet.",
    PERSONAL_PROFILES="Personal profiles", BACKUPS_AND_PROFILES="Profiles & backups", CREATE_GRAPHICS_BACKUP="Create graphics backup", DELETE_BACKUP="Delete backup", DELETE_BACKUP_CONFIRM="Delete this backup permanently?", APPLY_PROFILE="Preview and apply profile", PROFILE_APPLY_CONFIRM="Apply personal profile?", PROFILE_APPLY_CONFIRM_TEXT="Apply the selected graphics profile? A backup will be created first.", GRAPHICS_ONLY_NOTICE="Interface & Gameplay is temporarily hidden while it is being redesigned.", RESTORE_SELECTED="Restore selected backup", BACKUP_LABEL="Backup", PROFILE_LABEL="Profile", RIGHT_CLICK_PROFILES="Right-click: profiles and backups", PENDING_FPS="The operation is queued until combat ends; FPS measurement will start afterwards.",
    MODE_UNIFIED_HELP="The same balanced graphics everywhere.", MODE_SPLIT_HELP="A lighter Blizzard raid and battleground profile.", MEASURED_LOCALLY="Measured on this character", SELECT_ITEM="Select an item below", NO_GRAPHICS_PROFILES="No graphics profiles saved yet.", RESTORE_COMPLETE="Graphics restored.", APPLY_FAILED="The operation could not be applied.",
  },
  ruRU = {
    APPLY_AND_MEASURE="Применить и измерить FPS", APPLY_CONFIRM="Применить настройки графики?", APPLY_CONFIRM_TEXT="Применить проверенные изменения (%d)? Сначала будет создана резервная копия графики.", SETTINGS_APPLIED="Графика применена. Измеряем FPS…",
    FPS_RESULT_FORMAT="Средний FPS: %d до %d, %+d FPS (%+d%%)", FPS_MEASURING="Измеряем FPS… не меняйте ракурс.", FPS_MEASURE_HELP="FPS измеряется локально до и после применения. Результат приблизительный и зависит от сцены, боя и фоновой нагрузки.", FPS_UNAVAILABLE="Сравнение FPS пока недоступно.", FPS_ESTIMATE="Локальная оценка FPS",
    VISUAL_PREVIEW="Превью сбалансированной графики", VISUAL_PREVIEW_NOTE="Иллюстративный пример: сохраняются чёткие силуэты, проецируемые эффекты и умеренные частицы.", UNDO="Вернуть назад", UNDO_CONFIRM="Вернуть предыдущую графику?", UNDO_CONFIRM_TEXT="Восстановить последнюю резервную копию графики? Сначала будет создана страховочная копия.", UNDO_UNAVAILABLE="Резервных копий графики пока нет.",
    PERSONAL_PROFILES="Личные профили", BACKUPS_AND_PROFILES="Профили и бэкапы", CREATE_GRAPHICS_BACKUP="Создать бэкап графики", DELETE_BACKUP="Удалить бэкап", DELETE_BACKUP_CONFIRM="Удалить этот бэкап безвозвратно?", APPLY_PROFILE="Проверить и применить профиль", PROFILE_APPLY_CONFIRM="Применить личный профиль?", PROFILE_APPLY_CONFIRM_TEXT="Применить выбранный профиль графики? Сначала будет создан бэкап.", GRAPHICS_ONLY_NOTICE="Раздел «Интерфейс и игра» временно скрыт на время переработки.", RESTORE_SELECTED="Восстановить выбранный бэкап", BACKUP_LABEL="Бэкап", PROFILE_LABEL="Профиль", RIGHT_CLICK_PROFILES="Правая кнопка: профили и бэкапы", PENDING_FPS="Операция выполнится после боя; затем начнётся измерение FPS.",
    MODE_UNIFIED_HELP="Одинаковая сбалансированная графика везде.", MODE_SPLIT_HELP="Облегчённый профиль Blizzard для рейдов и полей боя.", MEASURED_LOCALLY="Измерено на этом персонаже", SELECT_ITEM="Выберите элемент ниже", NO_GRAPHICS_PROFILES="Профили графики пока не сохранены.", RESTORE_COMPLETE="Графика восстановлена.", APPLY_FAILED="Не удалось применить настройки.",
  },
  frFR = {
    APPLY_AND_MEASURE="Appliquer et mesurer les IPS", APPLY_CONFIRM="Appliquer les graphismes ?", APPLY_CONFIRM_TEXT="Appliquer %d modifications vérifiées ? Une sauvegarde graphique sera créée.", SETTINGS_APPLIED="Graphismes appliqués. Mesure des IPS…", FPS_RESULT_FORMAT="IPS moyennes : %d → %d, %+d IPS (%+d%%)", FPS_MEASURING="Mesure des IPS… restez au même endroit pendant 8 secondes.", FPS_MEASURE_HELP="Mesure locale avant et après. Le résultat reste une estimation dépendant de la scène.", FPS_UNAVAILABLE="Comparaison des IPS indisponible.", FPS_ESTIMATE="Estimation locale des IPS", VISUAL_PREVIEW="Aperçu graphique équilibré", VISUAL_PREVIEW_NOTE="Aperçu illustratif : silhouettes, effets projetés et particules lisibles.", UNDO="Annuler les changements", UNDO_CONFIRM="Restaurer les graphismes précédents ?", UNDO_CONFIRM_TEXT="Restaurer la dernière sauvegarde graphique ? Une sauvegarde de sécurité sera créée.", UNDO_UNAVAILABLE="Aucune sauvegarde graphique disponible.", PERSONAL_PROFILES="Profils personnels", BACKUPS_AND_PROFILES="Profils et sauvegardes", CREATE_GRAPHICS_BACKUP="Créer une sauvegarde graphique", DELETE_BACKUP="Supprimer la sauvegarde", DELETE_BACKUP_CONFIRM="Supprimer définitivement cette sauvegarde ?", APPLY_PROFILE="Aperçu et application", PROFILE_APPLY_CONFIRM="Appliquer le profil personnel ?", PROFILE_APPLY_CONFIRM_TEXT="Appliquer le profil graphique sélectionné ?", GRAPHICS_ONLY_NOTICE="Interface et jeu est temporairement masqué pendant sa refonte.", RESTORE_SELECTED="Restaurer la sauvegarde", BACKUP_LABEL="Sauvegarde", PROFILE_LABEL="Profil", RIGHT_CLICK_PROFILES="Clic droit : profils et sauvegardes", PENDING_FPS="Opération en attente de la fin du combat ; mesure ensuite.", MODE_UNIFIED_HELP="Les mêmes graphismes équilibrés partout.", MODE_SPLIT_HELP="Profil Blizzard allégé pour raids et champs de bataille.", MEASURED_LOCALLY="Mesuré sur ce personnage", SELECT_ITEM="Sélectionnez un élément", NO_GRAPHICS_PROFILES="Aucun profil graphique enregistré.", RESTORE_COMPLETE="Graphismes restaurés.", APPLY_FAILED="Impossible d’appliquer les réglages.",
  },
  deDE = {
    APPLY_AND_MEASURE="Anwenden und FPS messen", APPLY_CONFIRM="Grafikeinstellungen anwenden?", APPLY_CONFIRM_TEXT="%d geprüfte Änderungen anwenden? Zuerst wird ein Grafik-Backup erstellt.", SETTINGS_APPLIED="Grafik angewendet. FPS werden gemessen…", FPS_RESULT_FORMAT="Durchschnittliche FPS: %d → %d, %+d FPS (%+d%%)", FPS_MEASURING="FPS-Messung… 8 Sekunden am selben Ort bleiben.", FPS_MEASURE_HELP="Lokale Vorher-Nachher-Messung; das Ergebnis ist eine szenenabhängige Schätzung.", FPS_UNAVAILABLE="Noch kein FPS-Vergleich verfügbar.", FPS_ESTIMATE="Lokale FPS-Schätzung", VISUAL_PREVIEW="Vorschau ausgewogener Grafik", VISUAL_PREVIEW_NOTE="Illustrative Vorschau mit klaren Silhouetten, Bodeneffekten und maßvollen Partikeln.", UNDO="Grafik zurücksetzen", UNDO_CONFIRM="Vorherige Grafik wiederherstellen?", UNDO_CONFIRM_TEXT="Letztes Grafik-Backup wiederherstellen? Zuerst wird ein Sicherheits-Backup erstellt.", UNDO_UNAVAILABLE="Kein Grafik-Backup verfügbar.", PERSONAL_PROFILES="Persönliche Profile", BACKUPS_AND_PROFILES="Profile & Backups", CREATE_GRAPHICS_BACKUP="Grafik-Backup erstellen", DELETE_BACKUP="Backup löschen", DELETE_BACKUP_CONFIRM="Dieses Backup dauerhaft löschen?", APPLY_PROFILE="Profil prüfen und anwenden", PROFILE_APPLY_CONFIRM="Persönliches Profil anwenden?", PROFILE_APPLY_CONFIRM_TEXT="Das gewählte Grafikprofil anwenden?", GRAPHICS_ONLY_NOTICE="Interface & Gameplay ist während der Überarbeitung vorübergehend ausgeblendet.", RESTORE_SELECTED="Gewähltes Backup wiederherstellen", BACKUP_LABEL="Backup", PROFILE_LABEL="Profil", RIGHT_CLICK_PROFILES="Rechtsklick: Profile und Backups", PENDING_FPS="Wird nach dem Kampf angewendet und anschließend gemessen.", MODE_UNIFIED_HELP="Überall dieselbe ausgewogene Grafik.", MODE_SPLIT_HELP="Leichteres Blizzard-Profil für Schlachtzüge und Schlachtfelder.", MEASURED_LOCALLY="Auf diesem Charakter gemessen", SELECT_ITEM="Element auswählen", NO_GRAPHICS_PROFILES="Noch keine Grafikprofile gespeichert.", RESTORE_COMPLETE="Grafik wiederhergestellt.", APPLY_FAILED="Einstellungen konnten nicht angewendet werden.",
  },
}

strings.esES = {
  APPLY_AND_MEASURE="Aplicar y medir FPS", APPLY_CONFIRM="¿Aplicar los gráficos?", APPLY_CONFIRM_TEXT="¿Aplicar %d cambios revisados? Primero se creará una copia de gráficos.", SETTINGS_APPLIED="Gráficos aplicados. Midiendo FPS…", FPS_RESULT_FORMAT="FPS medios: %d → %d, %+d FPS (%+d%%)", FPS_MEASURING="Midiendo FPS… permanece en el mismo lugar 8 segundos.", FPS_MEASURE_HELP="Medición local antes y después; el resultado es una estimación dependiente de la escena.", FPS_UNAVAILABLE="Aún no hay comparación de FPS.", FPS_ESTIMATE="Estimación local de FPS", VISUAL_PREVIEW="Vista previa equilibrada", VISUAL_PREVIEW_NOTE="Ejemplo ilustrativo con siluetas y efectos de suelo claros y partículas moderadas.", UNDO="Deshacer cambios", UNDO_CONFIRM="¿Restaurar los gráficos anteriores?", UNDO_CONFIRM_TEXT="¿Restaurar la última copia de gráficos? Se creará una copia de seguridad.", UNDO_UNAVAILABLE="No hay copias de gráficos.", PERSONAL_PROFILES="Perfiles personales", BACKUPS_AND_PROFILES="Perfiles y copias", CREATE_GRAPHICS_BACKUP="Crear copia de gráficos", DELETE_BACKUP="Eliminar copia", DELETE_BACKUP_CONFIRM="¿Eliminar esta copia permanentemente?", APPLY_PROFILE="Revisar y aplicar perfil", PROFILE_APPLY_CONFIRM="¿Aplicar perfil personal?", PROFILE_APPLY_CONFIRM_TEXT="¿Aplicar el perfil gráfico seleccionado?", GRAPHICS_ONLY_NOTICE="Interfaz y juego está oculto temporalmente durante su rediseño.", RESTORE_SELECTED="Restaurar copia seleccionada", BACKUP_LABEL="Copia", PROFILE_LABEL="Perfil", RIGHT_CLICK_PROFILES="Clic derecho: perfiles y copias", PENDING_FPS="Se aplicará al terminar el combate y se medirá después.", MODE_UNIFIED_HELP="Los mismos gráficos equilibrados en todas partes.", MODE_SPLIT_HELP="Perfil de Blizzard más ligero para bandas y campos de batalla.", MEASURED_LOCALLY="Medido en este personaje", SELECT_ITEM="Selecciona un elemento", NO_GRAPHICS_PROFILES="No hay perfiles gráficos guardados.", RESTORE_COMPLETE="Gráficos restaurados.", APPLY_FAILED="No se pudieron aplicar los ajustes.",
}
strings.esMX = strings.esES
strings.ptBR = {
  APPLY_AND_MEASURE="Aplicar e medir FPS", APPLY_CONFIRM="Aplicar gráficos?", APPLY_CONFIRM_TEXT="Aplicar %d alterações revisadas? Um backup gráfico será criado primeiro.", SETTINGS_APPLIED="Gráficos aplicados. Medindo FPS…", FPS_RESULT_FORMAT="FPS médio: %d → %d, %+d FPS (%+d%%)", FPS_MEASURING="Medindo FPS… fique no mesmo lugar por 8 segundos.", FPS_MEASURE_HELP="Medição local antes e depois; o resultado é uma estimativa dependente da cena.", FPS_UNAVAILABLE="Comparação de FPS ainda indisponível.", FPS_ESTIMATE="Estimativa local de FPS", VISUAL_PREVIEW="Prévia gráfica equilibrada", VISUAL_PREVIEW_NOTE="Exemplo ilustrativo com silhuetas e efeitos no chão claros e partículas moderadas.", UNDO="Desfazer gráficos", UNDO_CONFIRM="Restaurar gráficos anteriores?", UNDO_CONFIRM_TEXT="Restaurar o último backup gráfico? Um backup de segurança será criado.", UNDO_UNAVAILABLE="Nenhum backup gráfico disponível.", PERSONAL_PROFILES="Perfis pessoais", BACKUPS_AND_PROFILES="Perfis e backups", CREATE_GRAPHICS_BACKUP="Criar backup gráfico", DELETE_BACKUP="Excluir backup", DELETE_BACKUP_CONFIRM="Excluir este backup permanentemente?", APPLY_PROFILE="Revisar e aplicar perfil", PROFILE_APPLY_CONFIRM="Aplicar perfil pessoal?", PROFILE_APPLY_CONFIRM_TEXT="Aplicar o perfil gráfico selecionado?", GRAPHICS_ONLY_NOTICE="Interface e jogabilidade está oculto temporariamente durante a reformulação.", RESTORE_SELECTED="Restaurar backup selecionado", BACKUP_LABEL="Backup", PROFILE_LABEL="Perfil", RIGHT_CLICK_PROFILES="Clique direito: perfis e backups", PENDING_FPS="Será aplicado após o combate e medido em seguida.", MODE_UNIFIED_HELP="Os mesmos gráficos equilibrados em todos os lugares.", MODE_SPLIT_HELP="Perfil Blizzard mais leve para raides e campos de batalha.", MEASURED_LOCALLY="Medido neste personagem", SELECT_ITEM="Selecione um item", NO_GRAPHICS_PROFILES="Nenhum perfil gráfico salvo.", RESTORE_COMPLETE="Gráficos restaurados.", APPLY_FAILED="Não foi possível aplicar as configurações.",
}
strings.koKR = {
  APPLY_AND_MEASURE="적용 후 FPS 측정", APPLY_CONFIRM="그래픽 설정을 적용할까요?", APPLY_CONFIRM_TEXT="검토된 변경 %d개를 적용할까요? 먼저 그래픽 백업을 만듭니다.", SETTINGS_APPLIED="그래픽을 적용했습니다. FPS 측정 중…", FPS_RESULT_FORMAT="평균 FPS: %d → %d, %+d FPS (%+d%%)", FPS_MEASURING="FPS 측정 중… 8초 동안 같은 위치에 있으세요.", FPS_MEASURE_HELP="적용 전후를 로컬에서 측정한 장면별 추정치입니다.", FPS_UNAVAILABLE="아직 FPS 비교가 없습니다.", FPS_ESTIMATE="로컬 FPS 추정", VISUAL_PREVIEW="균형 그래픽 미리보기", VISUAL_PREVIEW_NOTE="선명한 윤곽, 바닥 효과와 적절한 입자를 보여 주는 예시입니다.", UNDO="그래픽 되돌리기", UNDO_CONFIRM="이전 그래픽을 복원할까요?", UNDO_CONFIRM_TEXT="최신 그래픽 백업을 복원할까요? 안전 백업을 먼저 만듭니다.", UNDO_UNAVAILABLE="사용 가능한 그래픽 백업이 없습니다.", PERSONAL_PROFILES="개인 프로필", BACKUPS_AND_PROFILES="프로필 및 백업", CREATE_GRAPHICS_BACKUP="그래픽 백업 만들기", DELETE_BACKUP="백업 삭제", DELETE_BACKUP_CONFIRM="이 백업을 영구 삭제할까요?", APPLY_PROFILE="프로필 확인 및 적용", PROFILE_APPLY_CONFIRM="개인 프로필을 적용할까요?", PROFILE_APPLY_CONFIRM_TEXT="선택한 그래픽 프로필을 적용할까요?", GRAPHICS_ONLY_NOTICE="인터페이스 및 게임플레이는 재설계 중이라 임시로 숨겨졌습니다.", RESTORE_SELECTED="선택한 백업 복원", BACKUP_LABEL="백업", PROFILE_LABEL="프로필", RIGHT_CLICK_PROFILES="오른쪽 클릭: 프로필 및 백업", PENDING_FPS="전투 후 적용하고 이어서 측정합니다.", MODE_UNIFIED_HELP="어디서나 동일한 균형 그래픽입니다.", MODE_SPLIT_HELP="공격대와 전장용 가벼운 Blizzard 프로필입니다.", MEASURED_LOCALLY="이 캐릭터에서 측정", SELECT_ITEM="항목을 선택하세요", NO_GRAPHICS_PROFILES="저장된 그래픽 프로필이 없습니다.", RESTORE_COMPLETE="그래픽을 복원했습니다.", APPLY_FAILED="설정을 적용하지 못했습니다.",
}
strings.zhCN = {
  APPLY_AND_MEASURE="应用并测量帧率", APPLY_CONFIRM="应用图形设置？", APPLY_CONFIRM_TEXT="应用 %d 项已审核更改？将先创建图形备份。", SETTINGS_APPLIED="图形设置已应用，正在测量帧率…", FPS_RESULT_FORMAT="平均帧率：%d → %d，%+d FPS（%+d%%）", FPS_MEASURING="正在测量帧率…请在原地停留 8 秒。", FPS_MEASURE_HELP="本机应用前后测量；结果是随场景变化的估算值。", FPS_UNAVAILABLE="暂无帧率对比。", FPS_ESTIMATE="本机帧率估算", VISUAL_PREVIEW="均衡图形预览", VISUAL_PREVIEW_NOTE="示意预览：保留清晰轮廓、地面效果和适量粒子。", UNDO="撤销图形更改", UNDO_CONFIRM="恢复之前的图形设置？", UNDO_CONFIRM_TEXT="恢复最新图形备份？将先创建安全备份。", UNDO_UNAVAILABLE="暂无图形备份。", PERSONAL_PROFILES="个人配置", BACKUPS_AND_PROFILES="配置与备份", CREATE_GRAPHICS_BACKUP="创建图形备份", DELETE_BACKUP="删除备份", DELETE_BACKUP_CONFIRM="永久删除此备份？", APPLY_PROFILE="预览并应用配置", PROFILE_APPLY_CONFIRM="应用个人配置？", PROFILE_APPLY_CONFIRM_TEXT="应用所选图形配置？", GRAPHICS_ONLY_NOTICE="界面与游戏功能正在重新设计，暂时隐藏。", RESTORE_SELECTED="恢复所选备份", BACKUP_LABEL="备份", PROFILE_LABEL="配置", RIGHT_CLICK_PROFILES="右键：配置与备份", PENDING_FPS="战斗结束后应用，随后开始测量。", MODE_UNIFIED_HELP="所有场景使用相同的均衡图形。", MODE_SPLIT_HELP="团队和战场使用较轻的 Blizzard 配置。", MEASURED_LOCALLY="在此角色上测量", SELECT_ITEM="请在下方选择项目", NO_GRAPHICS_PROFILES="尚未保存图形配置。", RESTORE_COMPLETE="图形设置已恢复。", APPLY_FAILED="无法应用设置。",
}
strings.zhTW = {
  APPLY_AND_MEASURE="套用並測量幀率", APPLY_CONFIRM="套用圖形設定？", APPLY_CONFIRM_TEXT="套用 %d 項已檢查變更？將先建立圖形備份。", SETTINGS_APPLIED="圖形設定已套用，正在測量幀率…", FPS_RESULT_FORMAT="平均幀率：%d → %d，%+d FPS（%+d%%）", FPS_MEASURING="正在測量幀率…請在原地停留 8 秒。", FPS_MEASURE_HELP="本機套用前後測量；結果是隨場景變化的估算值。", FPS_UNAVAILABLE="尚無幀率比較。", FPS_ESTIMATE="本機幀率估算", VISUAL_PREVIEW="均衡圖形預覽", VISUAL_PREVIEW_NOTE="示意預覽：保留清晰輪廓、地面效果和適量粒子。", UNDO="復原圖形變更", UNDO_CONFIRM="還原之前的圖形設定？", UNDO_CONFIRM_TEXT="還原最新圖形備份？將先建立安全備份。", UNDO_UNAVAILABLE="尚無圖形備份。", PERSONAL_PROFILES="個人設定檔", BACKUPS_AND_PROFILES="設定檔與備份", CREATE_GRAPHICS_BACKUP="建立圖形備份", DELETE_BACKUP="刪除備份", DELETE_BACKUP_CONFIRM="永久刪除此備份？", APPLY_PROFILE="預覽並套用設定檔", PROFILE_APPLY_CONFIRM="套用個人設定檔？", PROFILE_APPLY_CONFIRM_TEXT="套用所選圖形設定檔？", GRAPHICS_ONLY_NOTICE="介面與遊戲功能正在重新設計，暫時隱藏。", RESTORE_SELECTED="還原所選備份", BACKUP_LABEL="備份", PROFILE_LABEL="設定檔", RIGHT_CLICK_PROFILES="右鍵：設定檔與備份", PENDING_FPS="戰鬥結束後套用，隨後開始測量。", MODE_UNIFIED_HELP="所有場合使用相同的均衡圖形。", MODE_SPLIT_HELP="團隊與戰場使用較輕的 Blizzard 設定檔。", MEASURED_LOCALLY="在此角色上測量", SELECT_ITEM="請在下方選擇項目", NO_GRAPHICS_PROFILES="尚未儲存圖形設定檔。", RESTORE_COMPLETE="圖形設定已還原。", APPLY_FAILED="無法套用設定。",
}

for locale, values in pairs(strings) do
  STBS.Locale[locale] = STBS.Locale[locale] or {}
  for key, value in pairs(values) do STBS.Locale[locale][key] = value end
end

local experience = {
  ABOUT="About",
  ZONE_GRAPHICS="Zone Graphics",
  GRAPHICS_TITLE="Better FPS. Clear graphics.",
  LIVE_FPS="Current FPS",
  LIVE_FPS_FORMAT="%d FPS",
  FPS_READING="-- FPS",
  FPS_MEASURING="Measuring FPS… keep the same view.",
  VISUAL_PREVIEW="Real in-game example",
  READY="Ready - choose a mode, then apply",
  REVIEW_READY="Ready to apply - a backup will be created first",
  QUICK_START="Quick start",
  QUICK_START_TEXT="1. Choose PRO, Optimized or Quality.\n2. Choose a 5-second or accurate 20-second test.\n3. Click Apply, confirm and keep the same view.",
  SAVE_OWN_TITLE="Want to keep your current graphics?",
  SAVE_OWN_TEXT="Open Profiles and click Save Graphics before applying a preset.",
  PLAN_SUMMARY="Result: %d settings will change, %d are already correct, %d cannot be changed on this system.",
  PERFORMANCE_TUNED="Expensive effects are reduced where the visual cost is small.",
  QUALITY_PRESERVED="Textures, projected effects, particles and combat outlines stay readable.",
  HARDWARE_UNCHANGED="Resolution, render scale, FPS limits and latency settings are not touched.",
  MODE_SELECTED="Profile selected. Nothing has been applied yet.",
  PRESET_SELECTED="Preset selected. Nothing has been applied yet.",
  PRESET_PRO="PRO",
  PRESET_OPTIMIZED="Optimized",
  PRESET_QUALITY="Quality",
  UNIFIED="Same everywhere",
  SPLIT="Lighter raids",
  GRAPHICS_SELECTION_SUMMARY="PRO prioritizes FPS; Optimized is the default balance; Quality improves the picture without wasteful maximums. Lighter raids uses Blizzard's separate raid profile.",
  BENCHMARK_QUICK="Quick test · 5 sec",
  BENCHMARK_ACCURATE="Accurate test · 20 sec",
  BENCHMARK_SELECTED="Measurement mode selected.",
  PENDING_FPS="The operation is queued until combat ends. The apply result will be shown afterwards.",
  FPS_MEASURING_BEFORE="Accurate test: measuring current graphics… keep the same view.",
  FPS_MEASURING_AFTER="Accurate test: graphics applied, measuring the result…",
  ACCURATE_COMPLETE="Accurate 20-second comparison complete. 1% Low is included.",
  FPS_LOW_RESULT_FORMAT="1%% Low: %d  |TInterface\\Buttons\\UI-SpellbookIcon-NextPage-Up:12:12|t  %d FPS",
  FPS_RESULT_FORMAT="Average FPS: %d  |TInterface\\Buttons\\UI-SpellbookIcon-NextPage-Up:14:14|t  %d, %+d FPS (%+d%%)",
  SHOW_WIDGET="Show FPS & Ping",
  HIDE_WIDGET="Hide FPS & Ping",
  WIDGET_ENABLED="FPS and ping indicator enabled.",
  WIDGET_DISABLED="FPS and ping indicator disabled.",
  PERFORMANCE_WIDGET="FPS & Ping",
  PERFORMANCE_WIDGET_HELP="Live FPS and highest latency.\nCtrl + drag to move.",
  WIDGET_FPS_FORMAT="FPS %d",
  WIDGET_PING_FORMAT="Ping %d",
  ZONE_GRAPHICS_TITLE="Graphics for each type of content",
  ZONE_CURRENT="Current content",
  ZONE_GRAPHICS_HELP="Enable once, then click a row to cycle its preset. Settings change only when WoW reports a new content type.",
  ZONE_SAFE_NOTE="Zone Graphics is optional and off by default. Every real change creates a backup and uses the same verified transaction as manual apply.",
  ZONE_WORLD="World / City",
  ZONE_PARTY="Dungeon",
  ZONE_RAID="Raid",
  ZONE_PVP="PvP / Arena",
  ZONE_SCENARIO="Scenario / Delve",
  ZONE_ENABLE="Enable Zone Graphics",
  ZONE_DISABLE="Disable Zone Graphics",
  ZONE_APPLY_NOW="Apply for current content",
  ZONE_ENABLED="Zone Graphics enabled.",
  ZONE_DISABLED="Zone Graphics disabled.",
  ZONE_ALREADY_ACTIVE="The selected preset is already active here.",
  ZONE_APPLIED="Zone preset applied: %d settings changed.",
  ZONE_QUEUED="Zone preset queued until combat ends.",
  ZONE_MAPPING_SAVED="Zone preset saved. Apply it now or enter this content again.",
  PROFILE_SAVE_HELP="This saves your current built-in WoW graphics as a personal profile.",
  PROFILE_SAVED="Profile saved: %s",
  PROFILE_SAVE_FAILED="Profile was not saved",
  PROFILE_RENAMED="Profile renamed.",
  PROFILE_RENAME_FAILED="Profile was not renamed.",
  PROFILE_DELETED="Profile deleted.",
  BACKUP_CREATED="Graphics backup created.",
  BACKUP_CREATE_FAILED="Backup was not created.",
  BACKUP_DELETED="Backup deleted.",
  ITEM_SELECTED="Selected: %s",
  EXPORT_READY="Export created. Click Copy, then press Ctrl+C.",
  RELOAD_UI="Reload UI",
  RELOAD_CONFIRM="Reload the interface now?",
  RELOAD_CONFIRM_TEXT="Your graphics are saved. Reloading finishes the interface refresh and briefly returns you to the loading screen.",
  RELOAD_FAILED="WoW could not reload the interface.",
  SETTINGS_APPLIED_NO_MEASURE="Graphics applied. Click Reload UI to finish refreshing the interface.",
  ACTION_FAILED="The action was not completed.",
  ABOUT_TITLE="About S-Tier Blizz Settings",
  ABOUT_STATUS="Transparent by design - local only, reversible and documented",
  ABOUT_SOURCE_HEADER="Where the settings come from",
  ABOUT_SOURCE_BODY="The three presets are checked against Blizzard Retail UI source, documented CVar ranges and in-game validators. Competitor workflows informed the UX, but no closed-source code or visual identity was copied. Recommendations are based on the visual cost of shadows, effects, spell density and view distance - not on a copied 'graphics level' number.",
  ABOUT_BALANCE_HEADER="Why this balance",
  ABOUT_BALANCE_BODY="PRO prioritizes FPS, Optimized is the recommended balance, and Quality raises useful detail without blindly maxing every option. All preserve high texture quality, projected ground effects, particles and outlines needed for combat readability. Raid mode uses Blizzard's separate profile for heavier scenes.",
  ABOUT_TRUST_HEADER="Why you stay in control",
  ABOUT_TRUST_BODY="Every apply creates a graphics backup first. You see a short preview and confirm before changes. Undo and Profiles can restore previous values. The addon stores data locally, has no telemetry and never changes resolution, render scale, V-Sync or FPS caps.",
  ABOUT_LIMIT="FPS gains depend on your hardware, location and combat load. The shown comparison is a local estimate, not a guaranteed benchmark.",
  RESIZE_WINDOW="Drag to resize the addon window",
  IN_GAME_PREVIEW_HELP="A live world preview cannot be embedded in a WoW addon. After applying, use View result in game to inspect the real scene and Undo if needed.",
  VIEW_IN_GAME="View result in game",
  VIEW_IN_GAME_CHAT="Inspect the real game scene now. Reopen S-Tier Blizz Settings and use Undo if you want the previous graphics back.",
  PROFILES_TAB="Profiles", BACKUPS_TAB="Backups", TRANSFER_TAB="Import / Export", PROFILE_COUNT="Saved profiles: %d", BACKUP_COUNT="Graphics backups: %d",
  TRANSFER_TITLE="Share all addon settings", TRANSFER_HELP="Export creates one string with your current WoW graphics, selected preset and mode, Zone Graphics rules, measurement choice and personal profiles. Paste it on another account to restore the same setup.", TRANSFER_EXCLUDES="Device-specific window positions and backup history are not shared.",
  EXPORT_ALL="Export all settings", IMPORT_ALL="Import all settings", BUNDLE_EXPORT_READY="The full settings string is ready. Click Copy, then press Ctrl+C.", BUNDLE_EXPORT_FAILED="Could not export addon settings.", BUNDLE_IMPORT_HELP="Paste a complete STBSA1 settings string.", BUNDLE_IMPORT_FAILED="The settings string was not imported.", BUNDLE_IMPORT_SUMMARY="This will apply the shared graphics and replace personal profiles (%d). Preset: %s. A graphics backup will be created first.", IMPORT_ALL_CONFIRM="Import and apply", BUNDLE_IMPORTED="All shared addon settings were imported.",
  LIGHT_RAID_CHECK="Use lighter raid graphics", ACCURATE_CHECK="Accurate 20-second test", WIDGET_CHECK="Show FPS & Ping", ZONE_CHECK="Enable Zone Graphics",
  TRANSFER_READY="Ready to copy or paste a settings string.",
}

local russianExperience = {
  ABOUT="Об аддоне", ZONE_GRAPHICS="Графика по зонам", GRAPHICS_TITLE="Больше FPS. Чёткая графика.", LIVE_FPS="Текущий FPS", FPS_MEASURING="Измеряем FPS… не меняйте ракурс.", VISUAL_PREVIEW="Реальный пример из игры", READY="Готово — выберите профиль и примените", REVIEW_READY="Всё готово — перед применением будет создан бэкап",
  QUICK_START="Быстрый старт", QUICK_START_TEXT="1. Выберите PRO, Оптимальный или Качество.\n2. Выберите быстрый замер 5 секунд или точный 20 секунд.\n3. Нажмите «Применить» и не меняйте ракурс.", SAVE_OWN_TITLE="Хотите сохранить текущую графику?", SAVE_OWN_TEXT="Откройте «Профили» и нажмите «Сохранить графику» до применения пресета.",
  PLAN_SUMMARY="Результат: будет изменено %d настроек, %d уже настроены, %d недоступны на этой системе.", PERFORMANCE_TUNED="Тяжёлые эффекты снижены там, где потеря качества почти незаметна.", QUALITY_PRESERVED="Качество текстур, эффекты на земле, частицы и контуры остаются читаемыми.", HARDWARE_UNCHANGED="Разрешение, масштаб рендера, лимиты FPS и задержка не меняются.",
  MODE_SELECTED="Режим зон выбран. Настройки ещё не применены.", PRESET_SELECTED="Пресет выбран. Настройки ещё не применены.", PRESET_PRO="PRO", PRESET_OPTIMIZED="Оптимальный", PRESET_QUALITY="Качество", UNIFIED="Одинаково везде", SPLIT="Облегчённый рейд", GRAPHICS_SELECTION_SUMMARY="PRO отдаёт приоритет FPS; Оптимальный — рекомендуемый баланс; Качество улучшает картинку без бесполезных максимумов. Облегчённый рейд использует отдельный профиль Blizzard.", BENCHMARK_QUICK="Быстрый замер · 5 сек", BENCHMARK_ACCURATE="Точный замер · 20 сек", BENCHMARK_SELECTED="Режим замера выбран.", PENDING_FPS="Операция выполнится после боя. Затем аддон покажет результат применения.", FPS_MEASURING_BEFORE="Точный замер: измеряем текущую графику… не меняйте ракурс.", FPS_MEASURING_AFTER="Точный замер: графика применена, измеряем результат…", ACCURATE_COMPLETE="Точное сравнение за 20 секунд завершено. Учтён 1% Low.", FPS_LOW_RESULT_FORMAT="1%% Low: %d  |TInterface\\Buttons\\UI-SpellbookIcon-NextPage-Up:12:12|t  %d FPS", FPS_RESULT_FORMAT="Средний FPS: %d  |TInterface\\Buttons\\UI-SpellbookIcon-NextPage-Up:14:14|t  %d, %+d FPS (%+d%%)", SHOW_WIDGET="Показать FPS и пинг", HIDE_WIDGET="Скрыть FPS и пинг", WIDGET_ENABLED="Индикатор FPS и пинга включён.", WIDGET_DISABLED="Индикатор FPS и пинга выключен.", PERFORMANCE_WIDGET="FPS и пинг", PERFORMANCE_WIDGET_HELP="Текущий FPS и максимальный пинг.\nCtrl + перетаскивание — переместить.", WIDGET_FPS_FORMAT="FPS %d", WIDGET_PING_FORMAT="Пинг %d",
  ZONE_GRAPHICS_TITLE="Графика для каждого типа контента", ZONE_CURRENT="Сейчас вы находитесь", ZONE_GRAPHICS_HELP="Включите функцию один раз, затем нажимайте на строки, чтобы менять пресет. Графика переключается только при смене типа контента.", ZONE_SAFE_NOTE="Функция необязательная и изначально выключена. Перед каждым реальным изменением создаётся бэкап и выполняется проверенная транзакция.", ZONE_WORLD="Открытый мир / Город", ZONE_PARTY="Подземелье", ZONE_RAID="Рейд", ZONE_PVP="PvP / Арена", ZONE_SCENARIO="Сценарий / Вылазка", ZONE_ENABLE="Включить графику по зонам", ZONE_DISABLE="Выключить графику по зонам", ZONE_APPLY_NOW="Применить для текущей зоны", ZONE_ENABLED="Графика по зонам включена.", ZONE_DISABLED="Графика по зонам выключена.", ZONE_ALREADY_ACTIVE="Нужный пресет уже действует в этой зоне.", ZONE_APPLIED="Пресет зоны применён: изменено настроек — %d.", ZONE_QUEUED="Пресет зоны применится после боя.", ZONE_MAPPING_SAVED="Пресет зоны сохранён. Примените сейчас или войдите в этот тип контента снова.",
  PROFILE_SAVE_HELP="Текущая встроенная графика WoW сохранится как личный профиль.", PROFILE_SAVED="Профиль сохранён: %s", PROFILE_SAVE_FAILED="Профиль не сохранён", PROFILE_RENAMED="Профиль переименован.", PROFILE_RENAME_FAILED="Профиль не переименован.", PROFILE_DELETED="Профиль удалён.", BACKUP_CREATED="Бэкап графики создан.", BACKUP_CREATE_FAILED="Бэкап не создан.", BACKUP_DELETED="Бэкап удалён.", ITEM_SELECTED="Выбрано: %s", EXPORT_READY="Экспорт создан. Нажмите «Копировать», затем Ctrl+C.", RELOAD_UI="Перезагрузить UI", RELOAD_CONFIRM="Перезагрузить интерфейс сейчас?", RELOAD_CONFIRM_TEXT="Настройки графики сохранены. Перезагрузка завершит обновление интерфейса и ненадолго вернёт вас на экран загрузки.", RELOAD_FAILED="Не удалось перезагрузить интерфейс WoW.", SETTINGS_APPLIED="Графика применена. Идёт быстрый замер FPS 5 секунд; затем станет доступна перезагрузка UI.", SETTINGS_APPLIED_NO_MEASURE="Графика применена. Нажмите «Перезагрузить UI», чтобы полностью обновить интерфейс.", ACTION_FAILED="Действие не выполнено.",
  ABOUT_TITLE="О S-Tier Blizz Settings", ABOUT_STATUS="Прозрачно: локально, обратимо и с документацией", ABOUT_SOURCE_HEADER="Откуда взяты настройки", ABOUT_SOURCE_BODY="Три пресета проверены по исходникам интерфейса Blizzard Retail, допустимым диапазонам CVar и внутриигровым валидаторам. У конкурентов изучались сценарии работы, но закрытый код и чужой визуальный стиль не копировались. Рекомендации учитывают цену теней, эффектов, плотности заклинаний и дальности прорисовки.", ABOUT_BALANCE_HEADER="Почему выбран этот баланс", ABOUT_BALANCE_BODY="PRO отдаёт приоритет FPS, Оптимальный даёт рекомендуемый баланс, а Качество повышает полезную детализацию без слепого включения максимумов. Все профили сохраняют качественные текстуры, эффекты на земле, частицы и контуры, важные в бою. Для рейдов используется отдельный профиль Blizzard.", ABOUT_TRUST_HEADER="Почему контроль остаётся у вас", ABOUT_TRUST_BODY="Перед каждым применением создаётся бэкап графики. Сначала показывается краткое описание и запрашивается подтверждение. «Вернуть назад» и «Профили» восстанавливают прежние значения. Аддон хранит всё локально, не использует телеметрию и не меняет разрешение, масштаб рендера, V-Sync и лимиты FPS.", ABOUT_LIMIT="Прирост FPS зависит от компьютера, места и нагрузки в бою. Сравнение — локальная оценка, а не гарантированный результат.",
  RESIZE_WINDOW="Потяните, чтобы изменить размер окна аддона", IN_GAME_PREVIEW_HELP="Встроить живой мир в окно аддона нельзя. После применения нажмите «Посмотреть результат в игре», оцените реальную сцену и при необходимости верните настройки назад.", VIEW_IN_GAME="Посмотреть результат в игре", VIEW_IN_GAME_CHAT="Оцените реальную сцену в игре. Снова откройте S-Tier Blizz Settings и нажмите «Вернуть назад», если захотите восстановить прежнюю графику.",
  PROFILES_TAB="Профили", BACKUPS_TAB="Бэкапы", TRANSFER_TAB="Импорт / экспорт", PROFILE_COUNT="Сохранено профилей: %d", BACKUP_COUNT="Бэкапов графики: %d", TRANSFER_TITLE="Обмен всеми настройками аддона", TRANSFER_HELP="Экспорт создаёт одну строку с текущей графикой WoW, выбранным пресетом и режимом, правилами графики по зонам, режимом замера и личными профилями. Вставьте её на другом аккаунте, чтобы получить ту же конфигурацию.", TRANSFER_EXCLUDES="Положение окон на конкретном экране и история бэкапов не передаются.", EXPORT_ALL="Экспортировать все настройки", IMPORT_ALL="Импортировать все настройки", BUNDLE_EXPORT_READY="Строка со всеми настройками готова. Нажмите «Копировать», затем Ctrl+C.", BUNDLE_EXPORT_FAILED="Не удалось экспортировать настройки аддона.", BUNDLE_IMPORT_HELP="Вставьте полную строку настроек STBSA1.", BUNDLE_IMPORT_FAILED="Строка настроек не импортирована.", BUNDLE_IMPORT_SUMMARY="Будет применена общая графика и заменены личные профили (%d). Пресет: %s. Сначала будет создан бэкап графики.", IMPORT_ALL_CONFIRM="Импортировать и применить", BUNDLE_IMPORTED="Все переданные настройки аддона импортированы.",
  LIGHT_RAID_CHECK="Облегчать графику в рейдах", ACCURATE_CHECK="Точный замер 20 секунд", WIDGET_CHECK="Показывать FPS и пинг", ZONE_CHECK="Включить графику по зонам",
  TRANSFER_READY="Можно копировать или вставлять строку настроек.",
}

for locale, values in pairs(STBS.Locale) do
  for key, value in pairs(experience) do values[key]=value end
end
for key, value in pairs(russianExperience) do STBS.Locale.ruRU[key]=value end
STBS.Locale.enUS.SETTINGS_APPLIED="Graphics applied. Measuring FPS for 5 seconds; Reload UI will unlock afterwards."
STBS.Locale.ruRU.LIVE_FPS_FORMAT="%d FPS"
STBS.Locale.ruRU.FPS_READING="-- FPS"
